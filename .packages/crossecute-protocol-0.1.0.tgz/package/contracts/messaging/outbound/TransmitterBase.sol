// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import {OutboundBase} from "./OutboundBase.sol";
import {RolesEnumerable} from "../Roles.sol";
import {ICommitFinalize, ICancel} from "../inbound/ReceiverBase.sol";
import {Executor} from "../Executor.sol";
import {Initializable} from "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import {ChainKey} from "../../addressing/ChainKey.sol";
import {Commitment} from "../Commitment.sol";
import {Payload} from "../Payload.sol";
import {Call} from "../Call.sol";
import {Erc7930} from "../../addressing/Erc7930.sol";
import {IERC7786GatewaySource} from "../IErc7786.sol";
import {DeliveryGas} from "../DeliveryGas.sol";

/// @title IConduitTransceiver
/// @notice Everything a conduit needs from the transceiver whose address it stores.
interface IConduitTransceiver {
    function treasury() external view returns (address);

    function bootstrap(
        bytes32 destinationChainKey,
        address owner,
        bytes32 salt,
        Call[] calldata calls,
        bytes[] calldata attributes
    ) external payable;

    function bootstrapElements(
        bytes32 destinationChainKey,
        address owner,
        bytes32 salt,
        bytes[] calldata elements,
        bytes[] calldata attributes
    ) external payable;

    function quoteBootstrap(
        bytes32 destinationChainKey,
        address owner,
        bytes32 salt,
        Call[] calldata calls,
        bytes[] calldata attributes
    ) external view returns (uint256);

    function quoteBootstrapElements(
        bytes32 destinationChainKey,
        address owner,
        bytes32 salt,
        bytes[] calldata elements,
        bytes[] calldata attributes
    ) external view returns (uint256);

    /// @notice The message the calling conduit sends itself, through its own transport, to stand
    ///         up on the chain `route` names. An empty `recipient` means this transceiver
    ///         carries the bootstrap, through `bootstrap` or `bootstrapElements`.
    function conduitBootstrap(bytes calldata route, address owner, bytes32 salt, bytes calldata body)
        external
        view
        returns (bytes memory recipient, bytes memory message);

    /// @notice Whether a destination reports its receiver address back, rather than this
    ///         chain deriving it. False wherever Ethereum's CREATE2 holds; true on zkSync, Tron, and
    ///         every non-EVM VM. Asked here because a conduit holds no registry.
    function reportsReceiver(bytes32 chainKey) external view returns (bool);

    /// @notice The chain identifier the governor configured a destination under, including one
    ///         this conduit has not bootstrapped yet.
    function routeTo(bytes32 chainKey) external view returns (bytes memory);

    /// @notice Where this conduit's receiver will sit on a chain that does not report it.
    function predictReceiver(bytes32 chainKey, address owner, bytes32 salt) external view returns (bytes memory);
}

/// @title TransmitterBase
/// @notice The per-user conduit on the home chain, and the source-side entry point. One
///         transmitter per protocol per user, routing to every destination.
///
/// @dev The destination is a parameter, not state: one transmitter fans out to every chain,
///      with one receiver per destination.
///
/// @dev Ownership is declared through `_checkOwner` and the modifier is
///      `onlyConduitOwner`, so a provider SDK that brings its own `onlyOwner` does not
///      collide. Every binding answers through `OwnableTransmitter`, whose inherited
///      `renounceOwnership` bricks the conduit, since every entry point is owner-gated. Left
///      available on purpose, so an owner can retire a conduit for good.
///
/// @dev No registry pointer: chainKeys derive purely and the transceiver does the directory
///      lookups.
///
/// @dev Commitments are hashed with the destination's chainKey, not this chain's:
///      `Commitment.hashCalls` seeds with the chain the receiver recomputes on.
abstract contract TransmitterBase is Initializable, OutboundBase, RolesEnumerable, Executor, IERC7786GatewaySource {
    /// The local transceiver for this protocol, which carries every message out.
    address public transceiver;
    /// The caller-chosen half of this conduit's CREATE2 salt, stored because `bootstrap` must
    /// state it and an address cannot be reversed into its salt.
    bytes32 public conduitSalt;
    /// The owner at creation, fixed for the conduit's life. It is the identity the CREATE2
    /// salt and every receiver address derive from, so bootstrap and prediction use it and not
    /// the current owner, which can change without moving any address.
    address public deployer;

    event TransmitterConfigured(address indexed owner, address indexed transceiver);
    event DestinationBootstrapped(bytes32 indexed destinationChainKey);
    /// @dev A destination reported an address this conduit could not derive. Distinct from
    ///      `CounterpartSet`, which also fires for the derived address at bootstrap.
    event DestinationReceiverReported(bytes32 indexed destinationChainKey, bytes receiver);
    /// @dev An execution the owner drove directly, as distinct from one a commitment discharged.
    event Executed(address indexed caller, uint256 callCount);
    event CrossecuteFeePaid(address indexed treasury, uint256 amount);

    error FeeTransferFailed(address treasury, uint256 amount);

    error NoTransceiver();
    /// @dev The recipient is not the receiver this conduit recorded for that chain.
    error RecipientIsNotThisConduit(bytes recipient);
    /// @dev No receiver known on that chain, so a payload would fail on delivery after the fee
    ///      is spent.
    error NotBootstrapped(bytes32 destinationChainKey);
    /// @dev `Proxy` arms once, so a second bootstrap would pay a fee to revert on arrival.
    error AlreadyBootstrapped(bytes32 destinationChainKey);
    /// @dev Something that is not this conduit's transceiver tried to report a receiver.
    error NotTransceiver(address caller);
    /// @dev A receiver's address is reported once; a second report, replayed or hostile, is
    ///      refused. See `_receiverPinned`.
    error ReceiverAlreadyReported(bytes32 destinationChainKey);
    /// @dev `Call[]` is what an EVM receiver executes and nothing else decodes it.
    error TypedPayloadToNonEvmDestination();
    /// @dev This conduit's balance, including the call's `msg.value`, cannot cover the fee.
    error InsufficientBalance(uint256 fee, uint256 balance);

    /// @notice Whether a bootstrap to `destinationChainKey` has been dispatched.
    ///
    /// @dev Dispatched, not landed: on a parity chain no report ever comes back, so nothing
    ///      here could wait for confirmation. Delivery is retryable at the provider, so a
    ///      bootstrap that reverts on arrival is pending, not lost. See
    ///      [Failure handling](../../../../../docs/message-flow.md#failure-handling).
    ///
    /// @dev A permanently undeliverable bootstrap (a wrong route, a destination that never
    ///      accepts it) blocks any retry from here. Both causes are write-once transceiver
    ///      misconfiguration that strands the conduit anyway.
    function isBootstrapped(bytes32 destinationChainKey) public view returns (bool) {
        return _bootstrapDispatched[destinationChainKey];
    }

    /// @notice Whether this conduit has been stood up on an EVM chain, by plain chain id.
    function isBootstrappedOn(uint256 destinationChainId) external view returns (bool) {
        return _bootstrapDispatched[ChainKey.forEvm(destinationChainId)];
    }

    /// @notice Whether this conduit can be sent to on `destinationChainKey` yet.
    /// @dev Equals `isBootstrapped` where the receiver's address is known at dispatch. On
    ///      zkSync, Tron, and every non-EVM VM it stays false until the destination's report lands.
    function isReachable(bytes32 destinationChainKey) external view returns (bool) {
        return hasCounterpart(destinationChainKey);
    }

    /// @notice This conduit's receiver on `destinationChainKey`, in that chain's own format.
    function destinationReceiverOn(bytes32 destinationChainKey) external view returns (bytes memory) {
        return counterpartOn(destinationChainKey);
    }

    /// Destinations whose receiver address has been reported and is now fixed.
    ///
    /// @dev Single-shot, with no owner override: the receiver address decides where a payload
    ///      lands. A wrong report is permanent for that destination, which requires the
    ///      transceiver on that chain to be compromised or misbuilt, losing the chain either way.
    mapping(bytes32 destinationChainKey => bool) private _receiverPinned;

    /// @notice Destinations this conduit has dispatched a bootstrap to.
    /// @dev Separate from the counterpart table: on a reporting chain a bootstrap is recorded,
    ///      so a second cannot be paid for, while the destination stays unreachable until its
    ///      receiver is known.
    mapping(bytes32 destinationChainKey => bool) private _bootstrapDispatched;

    /// @notice The transceiver reports where the destination actually created this conduit's
    ///         receiver.
    ///
    /// @dev Recorded as the counterpart `sendMessage` checks against, since the registry is
    ///      off the send path.
    ///
    /// @dev The transceiver authenticated the origin chain and derived this conduit from the
    ///      report's `(owner, salt)`, so it cannot aim a report at a conduit the reporting
    ///      chain did not name. It can report a wrong address for a real conduit on its own
    ///      chain, which is permanent (see `_receiverPinned`).
    function onDestinationReceiverReported(bytes32 destinationChainKey, bytes calldata receiver) external {
        if (msg.sender != transceiver) revert NotTransceiver(msg.sender);
        // The dispatch is what a report answers: on a reporting chain there is no
        // counterpart until it arrives.
        if (!_bootstrapDispatched[destinationChainKey]) {
            revert NotBootstrapped(destinationChainKey);
        }
        if (_receiverPinned[destinationChainKey]) {
            revert ReceiverAlreadyReported(destinationChainKey);
        }

        _receiverPinned[destinationChainKey] = true;
        _setCounterpart(destinationChainKey, receiver);
        emit DestinationReceiverReported(destinationChainKey, receiver);
    }

    /// @notice Whether a receiver report for this destination has been accepted.
    function isReceiverPinned(bytes32 destinationChainKey) external view returns (bool) {
        return _receiverPinned[destinationChainKey];
    }

    function _requireBootstrapped(bytes32 chainKey) private view {
        if (!hasCounterpart(chainKey)) revert NotBootstrapped(chainKey);
    }

    function _requireNotBootstrapped(bytes32 chainKey) private view {
        if (_bootstrapDispatched[chainKey]) revert AlreadyBootstrapped(chainKey);
    }

    /// @notice Reverts unless the caller is the owner. Declared, not implemented.
    function _checkOwner() internal view virtual;

    modifier onlyConduitOwner() {
        _checkOwner();
        _;
    }

    /* ================================== send =================================== */

    /// @notice Put a payload on the wire for this conduit's receiver on another chain.
    ///
    /// @dev The ERC-7786 source entry point, and the only send: the recipient is an ERC-7930
    ///      address carrying its own chain.
    ///
    /// @dev A built `bytes` payload cannot be asked whether it holds `Call[]` or opaque
    ///      elements, so pairing it with the right destination type is the caller's job;
    ///      `payloadForCalls` and `payloadForElements` build it. `bootstrap` decodes its body
    ///      in the destination's form instead.
    ///
    /// @dev The recipient must be this conduit's recorded receiver on that chain; see
    ///      `_requireOwnRecipient`.
    ///
    /// @dev Priced here, in the same call, and paid from this conduit's balance, so the owner
    ///      approves a payload rather than a payload and a price. `msg.value` only tops the
    ///      balance up.
    ///
    /// @return sendId Zero when the gateway has taken the message. A binding that returns
    ///         non-zero has a second step to perform and says so in its own NatSpec.
    function sendMessage(bytes calldata recipient, bytes calldata payload, bytes[] calldata attributes)
        external
        payable
        onlyConduitOwner
        returns (bytes32 sendId)
    {
        (uint256 providerFee, uint256 crossecuteFee) = quoteMessageBreakdown(recipient, payload, attributes);
        uint256 fee = providerFee + crossecuteFee;
        _requireFunded(fee);
        _payCrossecuteFee(crossecuteFee);

        emit MessageSent(
            bytes32(0), Erc7930.encodeEvm(block.chainid, address(this)), recipient, payload, fee, attributes
        );
        return _sendMessage(recipient, payload, attributes, providerFee);
    }

    /// @dev Collected outside the owner-controlled conduit and the transceiver's report float.
    ///      A provider revert unwinds this payment with the rest of the send.
    function _payCrossecuteFee(uint256 fee) private {
        if (fee == 0) return;
        address treasury = IConduitTransceiver(transceiver).treasury();
        if (treasury == address(0)) revert FeeTransferFailed(treasury, fee);
        emit CrossecuteFeePaid(treasury, fee);
        // forge-lint: disable-next-line(arbitrary-send-eth) the transceiver's write-once treasury
        (bool ok,) = treasury.call{value: fee}("");
        if (!ok) revert FeeTransferFailed(treasury, fee);
    }

    function _crossecuteFee(uint256 providerFee) internal pure virtual returns (uint256) {
        return providerFee / 10;
    }

    /// @notice Whether this conduit understands a per-send attribute. Required by ERC-7786
    ///         and answered by the binding; none here.
    function supportsAttribute(bytes4) external view virtual returns (bool) {
        return false;
    }

    /// @notice The recipient `sendMessage` takes for this conduit on `destinationChainId`: its
    ///         recorded receiver there, as an ERC-7930 address. Reverts until the receiver is
    ///         known.
    /// @dev Not this conduit's own address: the two differ wherever this chain or the
    ///      destination derives addresses differently from Ethereum.
    function recipientOn(uint256 destinationChainId) public view returns (bytes memory) {
        bytes32 chainKey = ChainKey.forEvm(destinationChainId);
        _requireBootstrapped(chainKey);
        return _recipientOn(chainKey);
    }

    /// @notice The ERC-7930 chain identifier for an EVM chain: `bootstrapPayload`'s first
    ///         argument, and the value a route is configured under.
    /// @dev `Erc7930` is internal-only, so off-chain callers need this builder to reach the
    ///      `bytes` entry points. It names a chain, where `recipientOn` names a conduit on one.
    function chainIdentifierFor(uint256 destinationChainId) public pure returns (bytes memory) {
        return _evmIdentifier(destinationChainId);
    }

    /// @notice The wire bytes for an EVM destination, which decodes `Call[]`.
    function payloadForCalls(Call[] calldata calls) public pure returns (bytes memory) {
        return Payload.encodeCalls(calls);
    }

    /// @notice The wire bytes for a destination whose calls this chain cannot express.
    function payloadForElements(bytes[] calldata elements) public pure returns (bytes memory) {
        return Payload.encodeElements(elements);
    }

    /// @notice The recipient must be the receiver this conduit recorded for that chain.
    ///         Returns the chainKey so nothing parses twice.
    ///
    /// @dev Compares against the stored counterpart, not `address(this)`: the receiver is at
    ///      this address only where Ethereum's CREATE2 holds, not on zkSync, Tron, or a non-EVM
    ///      chain. The whole recipient is compared, so the right conduit on the wrong chain is
    ///      refused too.
    ///
    /// @dev Checks bootstrap first so an unreached destination reverts `NotBootstrapped`
    ///      rather than `NoRouteFor` from `_recipientOn`. A stored receiver means the bootstrap
    ///      passed the registry's live check, which is never undone, so sends are not checked again.
    function _requireOwnRecipient(bytes calldata recipient) private view returns (bytes32 chainKey) {
        if (recipient.length == 0) revert NoDestination();

        chainKey = ChainKey.fromIdentifier(recipient);
        _requireBootstrapped(chainKey);

        if (keccak256(recipient) != keccak256(_recipientOn(chainKey))) {
            revert RecipientIsNotThisConduit(recipient);
        }
    }

    /* ================================= bootstrap =============================== */

    /// @notice Stand this conduit up on a chain that has none, and run a payload there.
    ///
    /// @dev Path B: with no receiver yet, the message goes to the transceiver on that chain.
    ///      It passes the owner and salt, from which the destination derives this conduit's
    ///      address; the transceiver checks they resolve to `msg.sender`. Where the transceiver
    ///      answers `conduitBootstrap` instead, this conduit sends that message through its own
    ///      transport, as `sendMessage` would.
    ///
    /// @dev `payload` is `bootstrapPayload(destinationChainIdentifier, body)`. The body is
    ///      decoded in the one form the destination's chain type implies (see `Payload`), so
    ///      what reaches the transceiver is always in that form.
    ///
    /// @dev Pays `_quoteBootstrap` from this conduit's balance, as `sendMessage` does. `quoteBootstrap` takes the same arguments, for
    ///      funding the balance ahead of time. Pass empty `attributes` for the gateway's default.
    function bootstrap(bytes calldata payload, bytes[] calldata attributes) external payable onlyConduitOwner {
        (bytes32 chainKey, bytes memory route, bool typed, bytes memory body) = _decodeBootstrap(payload);
        _markBootstrapped(chainKey, route);
        _sendBootstrap(chainKey, route, typed, body, attributes);
    }

    /// @notice The payload `bootstrap` takes: the destination's ERC-7930 chain identifier, and
    ///         the body its receiver runs on creation, built by `payloadForCalls` for an EVM
    ///         chain and `payloadForElements` for any other.
    function bootstrapPayload(bytes calldata destinationChainIdentifier, bytes calldata body)
        public
        pure
        returns (bytes memory)
    {
        return Payload.encodeBootstrap(destinationChainIdentifier, body);
    }

    /* ================================== quote ================================== */

    /// @notice What `sendMessage` would cost, in this chain's native currency.
    /// @dev Takes `sendMessage`'s arguments and applies its checks, so a quote never succeeds
    ///      for a send that would be refused. Ungated, so the balance can be sized off-chain.
    function quoteMessage(bytes calldata recipient, bytes calldata payload, bytes[] calldata attributes)
        external
        view
        override
        returns (uint256 nativeFee)
    {
        (uint256 providerFee, uint256 crossecuteFee) = quoteMessageBreakdown(recipient, payload, attributes);
        return providerFee + crossecuteFee;
    }

    /// @notice The provider quote and Crossecute fee, in source-chain native currency.
    /// @dev Applies the same recipient and payload checks as `sendMessage`.
    function quoteMessageBreakdown(bytes calldata recipient, bytes calldata payload, bytes[] calldata attributes)
        public
        view
        returns (uint256 providerFee, uint256 crossecuteFee)
    {
        _requireOwnRecipient(recipient);
        if (payload.length == 0) revert EmptyPayload();
        providerFee = _quoteMessage(recipient, payload, attributes);
        crossecuteFee = _crossecuteFee(providerFee);
    }

    /// @notice What `bootstrap` would cost, in this chain's native currency.
    /// @dev Decoded, checked and priced as `bootstrap` does it, through `_quoteBootstrap`. The
    ///      `(owner, salt)` check is not applied: a quote spends nothing and may be taken before
    ///      the conduit exists.
    function quoteBootstrap(bytes calldata payload, bytes[] calldata attributes)
        external
        view
        returns (uint256 nativeFee)
    {
        (bytes32 chainKey, bytes memory route, bool typed, bytes memory body) = _decodeBootstrap(payload);
        (nativeFee,,) = _quoteBootstrap(chainKey, route, typed, body, attributes);
    }

    /* =============================== shared code =============================== */

    /// @dev A `uint256` chain id is an `eip155` reference by construction.
    function _evmIdentifier(uint256 chainId) private pure returns (bytes memory) {
        if (chainId == 0) revert NoDestination();
        return Erc7930.encodeEvmChain(chainId);
    }

    /// @dev Everything `bootstrap` and `quoteBootstrap` read from a payload and check before
    ///      pricing it. The identifier is reduced to the bare chain identifier the route table
    ///      holds, so a conduit envelope names the same chain. `typed` is whether the
    ///      destination decodes `Call[]`.
    function _decodeBootstrap(bytes calldata payload)
        private
        view
        returns (bytes32 chainKey, bytes memory route, bool typed, bytes memory body)
    {
        if (transceiver == address(0)) revert NoTransceiver();
        bytes memory identifier;
        (identifier, body) = Payload.decodeBootstrap(payload);
        if (identifier.length == 0) revert NoDestination();
        if (body.length == 0) revert EmptyPayload();

        Erc7930.Interop memory io = Erc7930.parseStrict(identifier);
        route = Erc7930.encodeChainId(io.chainType, io.chainRef);
        typed = io.chainType == Erc7930.CT_EIP155;
        chainKey = keccak256(route);
        _requireNotBootstrapped(chainKey);
    }

    /// @notice What the bootstrap to `chainKey` costs, as `bootstrap` and `quoteBootstrap` both
    ///         price it, and the message this conduit sends when the transceiver hands one back.
    ///         `body` is `Call[]` when `typed`, opaque elements otherwise.
    /// @dev Runs after `_markBootstrapped` on a send and without it on a quote, so nothing it
    ///      reaches may read what that records.
    function _quoteBootstrap(
        bytes32 chainKey,
        bytes memory route,
        bool typed,
        bytes memory body,
        bytes[] calldata attributes
    ) private view returns (uint256 fee, bytes memory recipient, bytes memory message) {
        IConduitTransceiver t = IConduitTransceiver(transceiver);
        (recipient, message) = t.conduitBootstrap(route, deployer, conduitSalt, body);
        if (recipient.length != 0) {
            fee = _quoteMessage(recipient, message, attributes);
        } else if (typed) {
            fee = t.quoteBootstrap(chainKey, deployer, conduitSalt, Payload.decodeCallsFromMemory(body), attributes);
        } else {
            fee = t.quoteBootstrapElements(
                chainKey, deployer, conduitSalt, Payload.decodeElementsFromMemory(body), attributes
            );
        }
    }

    /// @notice Send the bootstrap to `chainKey`, paying its quote from this balance.
    /// @dev Runs after `_markBootstrapped`, so a re-entrant second bootstrap meets the record.
    function _sendBootstrap(
        bytes32 chainKey,
        bytes memory route,
        bool typed,
        bytes memory body,
        bytes[] calldata attributes
    ) private {
        (uint256 fee, bytes memory recipient, bytes memory message) =
            _quoteBootstrap(chainKey, route, typed, body, attributes);
        _requireFunded(fee);
        if (recipient.length != 0) {
            _sendMessage(recipient, message, attributes, fee);
            return;
        }

        IConduitTransceiver t = IConduitTransceiver(transceiver);
        // forge-lint: disable-start(arbitrary-send-eth) the write-once transceiver
        if (typed) {
            t.bootstrap{value: fee}(chainKey, deployer, conduitSalt, Payload.decodeCallsFromMemory(body), attributes);
        } else {
            t.bootstrapElements{value: fee}(
                chainKey, deployer, conduitSalt, Payload.decodeElementsFromMemory(body), attributes
            );
        }
        // forge-lint: disable-end(arbitrary-send-eth)
    }

    /// @dev Sends and bootstraps spend this balance, including any attached top-up.
    function _requireFunded(uint256 fee) private view {
        if (address(this).balance < fee) revert InsufficientBalance(fee, address(this).balance);
    }

    /// @dev Records the destination before the transport is called: that call reaches a
    ///      provider endpoint and arbitrary code, so a re-entrant second bootstrap meets the
    ///      record. A revert unwinds it with everything else.
    ///
    /// @dev Records the receiver only where its address is already known (the chain does not
    ///      report), as the transceiver predicts it there: this conduit's own address only when
    ///      both chains use Ethereum's CREATE2. On a reporting chain the destination stays
    ///      unreachable until the report arrives, rather than addressed at a guess.
    function _markBootstrapped(bytes32 chainKey, bytes memory route) private {
        _bootstrapDispatched[chainKey] = true;
        _setRoute(chainKey, route);

        IConduitTransceiver t = IConduitTransceiver(transceiver);
        if (!t.reportsReceiver(chainKey)) {
            _setCounterpart(chainKey, t.predictReceiver(chainKey, deployer, conduitSalt));
        }

        emit DestinationBootstrapped(chainKey);
    }

    /* ================================= execute ================================= */

    /// @notice Run a payload on this chain, with no bridge and no commitment.
    ///
    /// @dev Runs the calls itself: the conduit homed here is its transmitter, so there is no
    ///      receiver at home. Both ends share `Executor`'s loop, policy check, and
    ///      all-or-nothing rule.
    ///
    /// @dev Payable; value passes to the calls, and anything unspent stays at this
    ///      owner-controlled address.
    function execute(Call[] calldata calls) external payable onlyConduitOwner {
        if (calls.length == 0) revert EmptyExecution();
        emit Executed(msg.sender, calls.length);
        _execute(calls);
    }

    /* ============================== payload helpers ============================ */

    /// @notice The call that pins `commitment` on a receiver, for inclusion in a payload
    ///         bound for that receiver's chain.
    /// @dev Committing is a call, not a message kind: a payload whose single element is this
    ///      stores the hash on arrival, and anyone later supplies the array to `finalize`. The
    ///      receiver accepts it as a self-call from `_execute`.
    function commitmentCall(address receiver, bytes32 commitment) public pure returns (Call memory) {
        return Call({target: receiver, value: 0, data: abi.encodeCall(ICommitFinalize.commit, (commitment))});
    }

    /// @notice The call that withdraws an approval on a receiver, for inclusion in a payload
    ///         bound for that receiver's chain.
    /// @dev Names the approval by hash, so it cannot go stale in transit: the approval either
    ///      still exists or the call reverts.
    function cancellationCall(address receiver, bytes32 commitment) public pure returns (Call memory) {
        return Call({target: receiver, value: 0, data: abi.encodeCall(ICancel.cancel, (commitment))});
    }

    /* ================================= preview ================================= */

    /// @notice The commitment a payload will need on one EVM destination.
    ///
    /// @dev EVM destinations only. Every `Call[]` chain hashes with keccak256, which
    ///      `ReceiverBase` enforces from bytecode frozen alongside this, so the answer cannot go
    ///      stale. Non-EVM destinations are previewed through `ChainRegistry.commitmentFor`,
    ///      whose per-chain plugins can grow after this conduit is frozen.
    ///
    /// @dev `pure`, so it runs off-chain against the exact array the signers reviewed.
    function commitmentFor(uint256 destinationChainId, Call[] memory calls) public pure returns (bytes32) {
        return Commitment.hashCalls(ChainKey.forEvm(destinationChainId), calls);
    }

    /// @notice `commitmentFor`, for an EVM destination named by its ERC-7930 identifier.
    /// @dev Refuses a non-EVM identifier; `ChainRegistry.commitmentFor` answers those.
    function commitmentForChain(bytes calldata destinationChainIdentifier, Call[] memory calls)
        public
        pure
        returns (bytes32)
    {
        if (!Payload.isTypedDestination(destinationChainIdentifier)) {
            revert TypedPayloadToNonEvmDestination();
        }
        return Commitment.hashCalls(ChainKey.fromIdentifier(destinationChainIdentifier), calls);
    }

    /// @notice Accept ETH: the balance every send and bootstrap is paid from, and where a
    ///         provider's refund lands. Without `receive` a refund would revert the send.
    receive() external payable {}

    /// @inheritdoc OutboundBase
    /// @dev Path A: this conduit paid from its own balance. Path B refunds come here too, as
    ///      the transceiver's caller.
    function _refundTo() internal view override returns (address) {
        return address(this);
    }

    /// @inheritdoc OutboundBase
    function _defaultGas(bytes memory) internal pure override returns (uint256) {
        return DeliveryGas.PAYLOAD;
    }

    function __TransmitterBase_init(address owner_, address transceiver_, bytes32 salt_) internal onlyInitializing {
        if (transceiver_ == address(0)) revert NoTransceiver();

        transceiver = transceiver_;
        conduitSalt = salt_;
        deployer = owner_;
        emit TransmitterConfigured(owner_, transceiver_);
    }
}
